clear
data=xlsread('gene expression matrix.xlsx');
alpha=0.2;
boxsize=1.5;
weighted=1;
c = [];
kk=1;
cndm = condition_ndm(data,alpha,boxsize,kk);
xlswrite('CNDM.xlsx',cndm);