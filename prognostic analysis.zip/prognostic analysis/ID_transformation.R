#One-click emptying
rm(list = ls())
#Install and load the R package
if(length(getOption("CRAN"))==0) options(CRAN="https://mirrors.tuna.tsinghua.edu.cn/CRAN/")
if(!require("rtracklayer")) BiocManager::install("rtracklayer")
if(!require("tidyr")) BiocManager::install("tidyr")
if(!require("dplyr")) BiocManager::install("dplyr")
if(!require("DESeq2")) BiocManager::install("DESeq2")
if(!require("limma")) BiocManager::install("limma")
if(!require("edgeR")) BiocManager::install("edgeR")
library("tidyr")
library(stringr)
#Import expression profile data
setwd("D:\\srtp\\Single_cell_T2D\\Prognosis")
PAADdata=read.table("TCGA-PAAD.htseq_counts.tsv",header=T,sep='\t',row.names = 1)
load("gtf_gene.Rdata")
deg =PAADdata
#Add two columns
table(rownames(deg) %in% gtf_gene$gene_id)
#See if the line names are all in the 'gtf' file
rownames(deg)[!rownames(deg) %in% gtf_gene$gene_id]
an = gtf_gene[,c("gene_name","gene_id","gene_type")]
deg = merge
#Original gene expression matrix
write.csv(deg,file = "PAAD-gene_expression_60483.csv")
