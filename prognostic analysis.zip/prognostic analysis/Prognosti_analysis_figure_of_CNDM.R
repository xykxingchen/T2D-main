rm(list=ls())
setwd("D:\\srtp\\Single_cell_T2D\\Prognosis\\Batch_drawing")

exprSet1<- read.csv('24gene_CNDM.csv',header=T,row.names = 1,check.names=FALSE)
exprSet<-as.matrix(exprSet1)
class(exprSet)
surv = read.table("TCGA-PAAD.survival.tsv",header = T)
meta=surv
colnames(meta)=c('SAMPLE','event','ID','time')
library(stringr)
#Adjust the sequence of META ids to be the same as the exprSet column names  
meta=meta[match(str_sub(colnames(exprSet),1,12),meta$ID),]
identical(meta$ID,str_sub(colnames(exprSet),1,12))
library(survival)
library(survminer)
gs=rownames(exprSet)[1]
for (i in gs){
  splots <- lapply(gs, function(g){
    meta$gene=ifelse(exprSet[g,] > median(exprSet[g,]),'high','low')
    sfit1=survfit(Surv(time, event)~gene, data=meta)
    ggsurvplot(sfit1,pval =TRUE, data = meta, 
               ggtheme = theme_classic2(),#The theme of the survival graph
               legend="top", #Specify the location of the legend
               surv.median.line = "hv", #Median survival time
               legend.title = paste(i,"degree",sep="_"), #Specify the name of the legend group
               legend.labs = c("HighGroup","LowGroup"), #Specify the character vector of the legend label
               risk.table = TRUE)
  }) 
  res<-arrange_ggsurvplots(splots, print = F,  
                           ncol = 1, nrow = 1, risk.table.height = 0.4)
  ggsave(paste(i,"degree_surv.png",sep = "_"), res,width=7,height = 6)
  
}
