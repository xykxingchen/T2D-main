rm(list=ls())
setwd("D:\\srtp\\Singl_ecell_T2D\\Prognosis")
load("TCGA-CHOL_sur_model.Rdata")
exprSet<- read.csv('Survival_analysis_CNDM.csv',header=T,row.names = 1,check.names=FALSE)
surv = read.table("TCGA-PAAD.survival.tsv",header = T)
meta=surv
colnames(meta)=c('SAMPLE','event','ID','time')
library(stringr)
#Adjust the sequence of META ids to be the same as the exprSet column names 
meta=meta[match(str_sub(colnames(exprSet),1,12),meta$ID),]
identical(meta$ID,str_sub(colnames(exprSet),1,12))
#Batch Survival Analysis of logrank
library(survival)
library(survminer)
logrankfile = paste0(cancer_type,"_log_rank_p.Rdata")
if(!file.exists(logrankfile)){
  log_rank_p <- apply(exprSet , 1 , function(gene) {
    meta$group=ifelse(gene>median(gene),'high','low')  
    data.survdiff=survdiff(Surv(time, event)~group,data=meta)
    p.val = 1 - pchisq(data.survdiff$chisq, length(data.survdiff$n) - 1)
    return(p.val)
  })
  log_rank_p=sort(log_rank_p)
  save(log_rank_p,file = logrankfile)
}
load(logrankfile)

table(log_rank_p<0.05) 
lr = names(log_rank_p)[log_rank_p<0.05];length(lr)
lr <- as.data.frame(lr)
#Genes with p value of CNDM less than 0.05
write.csv(lr,file = "CNDM_p_value_less_than_0.05.csv")

