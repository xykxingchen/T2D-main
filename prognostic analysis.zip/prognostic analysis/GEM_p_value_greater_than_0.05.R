setwd("D:\\srtp\\Single_cell_T2D\\Prognosis")
rm(list = ls())
load("TCGA-CHOL_sur_model.Rdata")
exprSet<- read.csv('D:\\srtp\\Singl_ecell_T2D\\Prognosis\\Survival_analysis_GEN.csv',header=T,row.names = 1,check.names=FALSE)
surv = read.table("TCGA-PAAD.survival.tsv",header = T)
options(stringsAsFactors = F)
#Remove the cancer group.
library(stringr)
#Samples are grouped according to bits 14-15 of the ID.(tumor or normal)
table(str_sub(colnames(exprSet),14,15))
Group = ifelse(as.numeric(str_sub(colnames(exprSet),14,15)) < 10,'tumor','normal')
Group = factor(Group,levels = c("normal","tumor"))
table(Group)
exprSet=exprSet[,Group=='tumor']
#Standardize the expression matrix to get the gene expression matrix of running CNDM.
IDexprSet=exprSet
IDexprSet1<-log(1+IDexprSet)
write.csv(IDexprSet1,file = "GEM_of_run_CNDM.csv")
#Survival analysis data processing
library(stringr)
#1.Simplify clinical information and select columns to use
meta = surv
exprSet=exp[,Group=='tumor']
exprSet = log2(edgeR::cpm(exprSet)+1)
#Simplified column names for meta
colnames(meta)=c('SAMPLE','event','ID','time')
#The empty value is changed to NA
meta[meta==""]=NA
#2.Realize the matching of expression matrix and clinical information 
# Taking the patient as the center, the expression matrix is repeated according to the patient ID.
k = !duplicated(str_sub(colnames(exprSet),1,12));table(k)
exprSet = exprSet[,k]
#Adjust the sequence of META ids to be the same as the exprSet column names
meta=meta[match(str_sub(colnames(exprSet),1,12),meta$ID),]
identical(meta$ID,str_sub(colnames(exprSet),1,12))

#Batch Survival Analysis of logrank

logrankfile = paste0(cancer_type,"_log_rank_p.Rdata")
if(!file.exists(logrankfile)){
  log_rank_p <- apply(exprSet , 1 , function(gene){
    # gene=exprSet[1,]
    meta$group=ifelse(gene>median(gene),'high','low')  
    data.survdiff=survdiff(Surv(time, event)~group,data=meta)
    p.val = 1 - pchisq(data.survdiff$chisq, length(data.survdiff$n) - 1)
    return(p.val)
  })
  log_rank_p=sort(log_rank_p)
  save(log_rank_p,file = logrankfile)
}
load(logrankfile)
 
table(log_rank_p>0.05) 
lr = names(log_rank_p)[log_rank_p>0.05];length(lr)
lr <- as.data.frame(lr)
#Genes with p value of GEM greater than 0.05
write.csv(lr,file = "GEM_p_value_Greater_than_0.05.csv")
